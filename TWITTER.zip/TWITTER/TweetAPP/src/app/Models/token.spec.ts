import { Token } from './token';

describe('Token', () => {
  it('should create an instance', () => {
    expect(new Token()).toBeTruthy();
  });
});
